If you are unsure of which division to place a team,
have them solve the three problems given in this zip file.
These problems serve as a baseline for competing in Division 1.
Each problem has official input, output, as well as solutions
included.  If a team *cannot* solve these three problems, that 
team should compete in Division II.

While the solutions to each problem are included,  (far) below in this
README are hints as to the algorithm(s) that best fit the problems.




















































2011_SpeedRacer (Problem H): Math/Binary Search
2013_Escape (Problem E): Dijkstra
2014_Wormhole (Problem L): Floyd-Warshall)